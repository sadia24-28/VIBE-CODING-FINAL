# Tender Document Package Builder

Frontend-only React + Vite app. Open `requirements.json`, upload PDFs, match them to the required documents, enter expiry dates, and download `<tender_id>_Package.pdf`. Everything runs in the browser; no file leaves the machine.

```
npm install
npm run dev      # development
npm run build    # production build in dist/
```

Put the package generated from the sample pack in `output/` and screenshots in `screenshots/`.
