import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles.css';

class Boundary extends React.Component {
  state = { err: false };
  static getDerivedStateFromError() { return { err: true }; }
  render() {
    if (!this.state.err) return this.props.children;
    return (
      <div className="fatal">
        <p>Something went wrong. Please reload the page and try again.<br />কিছু ভুল হয়েছে। পৃষ্ঠাটি রিলোড করে আবার চেষ্টা করুন।</p>
        <button className="btn" onClick={() => location.reload()}>Reload / রিলোড</button>
      </div>
    );
  }
}
createRoot(document.getElementById('root')).render(<Boundary><App /></Boundary>);
