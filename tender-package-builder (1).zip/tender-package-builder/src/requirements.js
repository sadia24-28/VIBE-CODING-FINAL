const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(new Date(s + 'T00:00:00Z')) && new Date(s + 'T00:00:00Z').toISOString().slice(0, 10) === s;

// Parses and validates requirements.json text. Throws Error(message) on any problem.
export function parseRequirements(text) {
  let j;
  try { j = JSON.parse(String(text).replace(/^\uFEFF/, '')); }
  catch (e) { throw new Error('the file is not valid JSON (' + e.message + ')'); }
  const t = j && j.tender;
  if (!t || typeof t !== 'object') throw new Error('the "tender" section is missing');
  for (const k of ['tender_id', 'submission_deadline'])
    if (typeof t[k] !== 'string' || !t[k].trim()) throw new Error(`tender.${k} is missing`);
  if (!isDate(t.submission_deadline.trim())) throw new Error('tender.submission_deadline must be a real date in YYYY-MM-DD format');
  if (!Array.isArray(j.requirements) || !j.requirements.length) throw new Error('"requirements" must be a non-empty list');
  const seen = new Set();
  const reqs = j.requirements.map((r, i) => {
    const p = `requirements[${i}]`;
    if (!r || typeof r !== 'object') throw new Error(`${p} is not an object`);
    const id = String(r.id ?? '').trim();
    if (!id) throw new Error(`${p}.id is missing`);
    if (seen.has(id)) throw new Error(`${p}.id "${id}" is used twice`);
    seen.add(id);
    const order = Number(r.order);
    if (r.order === null || r.order === undefined || r.order === '' || !Number.isFinite(order)) throw new Error(`${p}.order must be a number`);
    if (!r.title_en && !r.title_bn) throw new Error(`${p} needs title_en or title_bn`);
    if (typeof r.mandatory !== 'boolean' || typeof r.has_expiry !== 'boolean') throw new Error(`${p}.mandatory and ${p}.has_expiry must be true or false`);
    return { id, order, title_en: String(r.title_en || ''), title_bn: String(r.title_bn || ''), mandatory: r.mandatory, has_expiry: r.has_expiry, _i: i };
  });
  reqs.sort((a, b) => a.order - b.order || a._i - b._i);
  const s = (k) => String(t[k] ?? '').trim();
  return {
    tender: { tender_id: s('tender_id'), title: s('title'), procuring_entity: s('procuring_entity'), bidder: s('bidder'), submission_deadline: s('submission_deadline') },
    reqs,
  };
}
