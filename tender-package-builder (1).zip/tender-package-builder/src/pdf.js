import { PDFDocument, StandardFonts, rgb, degrees } from 'pdf-lib';

export const MAX_FILES = 30;
export const MAX_BYTES = 50 * 1024 * 1024;
const BAND = 32; // footer strip added under every document page, so the footer never covers content

export async function sha256(bytes) {
  if (!globalThis.crypto?.subtle) throw new Error('hashing needs a secure (https) page');
  const h = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

export const looksLikePdf = (bytes) => new TextDecoder('latin1').decode(bytes.subarray(0, 1024)).includes('%PDF-');

// Returns the page count; throws Error with code 'enc' (password-protected) or 'bad' (damaged).
export async function inspectPdf(bytes) {
  let n;
  try { n = (await PDFDocument.load(bytes)).getPageCount(); }
  catch (e) {
    throw Object.assign(new Error('x'), { code: /encrypt/i.test(e?.message || '') || e?.name === 'EncryptedPDFError' ? 'enc' : 'bad' });
  }
  if (!n) throw Object.assign(new Error('x'), { code: 'bad' });
  return n;
}

// Standard fonts only cover Latin text: replace anything they cannot draw.
const safe = (font, s) => [...String(s ?? '')].map((c) => { try { font.widthOfTextAtSize(c, 1); return c; } catch { return c === '\n' || c === '\t' ? ' ' : '?'; } }).join('');

function wrap(font, s, size, max) {
  const out = []; let line = '';
  for (const w of safe(font, s).split(/\s+/).filter(Boolean)) {
    const t = line ? line + ' ' + w : w;
    if (font.widthOfTextAtSize(t, size) <= max) { line = t; continue; }
    if (line) out.push(line);
    line = w;
    while (font.widthOfTextAtSize(line, size) > max && line.length > 1) {
      let i = line.length - 1;
      while (i > 1 && font.widthOfTextAtSize(line.slice(0, i), size) > max) i--;
      out.push(line.slice(0, i)); line = line.slice(i);
    }
  }
  if (line) out.push(line);
  return out.length ? out : ['-'];
}

function fit(font, s, size, max) {
  s = safe(font, s);
  if (font.widthOfTextAtSize(s, size) <= max) return s;
  while (s.length > 1 && font.widthOfTextAtSize(s + '...', size) > max) s = s.slice(0, -1);
  return s + '...';
}

const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

// items: [{ req, name, bytes, pages }] already sorted by requirement order.
export async function buildPackage(tender, items) {
  const out = await PDFDocument.create();
  const font = await out.embedFont(StandardFonts.Helvetica);
  const bold = await out.embedFont(StandardFonts.HelveticaBold);
  let start = 2;
  items.forEach((it) => { it.start = start; start += it.pages; });

  // ---- Page 1: cover (English) ----
  const W = 595.28, H = 841.89, M = 50, ink = rgb(0.08, 0.13, 0.24), grey = rgb(0.4, 0.43, 0.5);
  const cover = out.addPage([W, H]);
  let y = H - 70;
  cover.drawText('TENDER SUBMISSION PACKAGE', { x: M, y, size: 20, font: bold, color: ink });
  y -= 14;
  cover.drawLine({ start: { x: M, y }, end: { x: W - M, y }, thickness: 1.5, color: ink });
  y -= 28;
  const fields = [
    ['Tender ID', tender.tender_id], ['Tender Title', tender.title], ['Procuring Entity', tender.procuring_entity],
    ['Bidder', tender.bidder], ['Submission Deadline', tender.submission_deadline], ['Package Created', today()],
  ];
  for (const [k, v] of fields) {
    cover.drawText(k, { x: M, y, size: 10, font: bold, color: grey });
    for (const ln of wrap(font, v || '-', 12, W - M - 190)) { cover.drawText(ln, { x: 190, y, size: 12, font, color: ink }); y -= 16; }
    y -= 6;
  }
  y -= 10;
  cover.drawText('Included Documents', { x: M, y, size: 14, font: bold, color: ink });
  y -= 10;
  cover.drawLine({ start: { x: M, y }, end: { x: W - M, y }, thickness: 0.5, color: grey });
  y -= 8;
  const lineH = Math.max(11, Math.min(22, (y - 60) / Math.max(items.length, 1)));
  const size = Math.min(11, lineH - 3);
  items.forEach((it, i) => {
    y -= lineH;
    const range = it.pages > 1 ? `pages ${it.start}-${it.start + it.pages - 1}` : `page ${it.start}`;
    const rw = font.widthOfTextAtSize(range, size);
    const title = it.req.title_en || it.req.title_bn;
    cover.drawText(fit(font, `${i + 1}. ${title}`, size, W - 2 * M - rw - 20), { x: M, y, size, font, color: ink });
    cover.drawText(range, { x: W - M - rw, y, size, font, color: grey });
  });
  if (!items.length) cover.drawText('(none)', { x: M, y: y - lineH, size: 11, font, color: grey });

  // ---- Documents, in order, every original page kept ----
  for (const it of items) {
    const src = await PDFDocument.load(it.bytes);
    const emb = await out.embedPdf(src, src.getPageIndices());
    emb.forEach((e, i) => {
      const rot = (((src.getPage(i).getRotation().angle % 360) + 360) % 360);
      const w = e.width, h = e.height;
      const pg = out.addPage(rot % 180 ? [h, w + BAND] : [w, h + BAND]);
      const o = rot === 90 ? { x: 0, y: w + BAND, rotate: degrees(-90) }
        : rot === 180 ? { x: w, y: h + BAND, rotate: degrees(180) }
        : rot === 270 ? { x: h, y: BAND, rotate: degrees(90) }
        : { x: 0, y: BAND };
      pg.drawPage(e, o);
    });
  }

  // ---- Footer on every page: <tender_id> | Page X of Y ----
  const pages = out.getPages(), total = pages.length;
  pages.forEach((pg, i) => {
    const text = safe(font, `${tender.tender_id} | Page ${i + 1} of ${total}`);
    const tw = font.widthOfTextAtSize(text, 9);
    pg.drawText(text, { x: Math.max(2, (pg.getWidth() - tw) / 2), y: i === 0 ? 26 : BAND / 2 - 3, size: 9, font, color: rgb(0.15, 0.15, 0.2) });
  });
  out.setTitle(safe(font, `${tender.tender_id} Package`));
  return out.save();
}
