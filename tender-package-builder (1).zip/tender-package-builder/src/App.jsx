import { useMemo, useState } from 'react';
import { MAX_FILES, MAX_BYTES, sha256, looksLikePdf, inspectPdf, buildPackage } from './pdf.js';
import { parseRequirements } from './requirements.js';
import { D, EN, BN } from './i18n.js';

const ORDER = ['missing', 'expiryNeeded', 'expired', 'notProvided', 'ok'];
const BLOCK = ['missing', 'expiryNeeded', 'expired'];
let seq = 0;
const nid = () => 'i' + ++seq;
const Badge = ({ k, lang }) => <span className={'badge s-' + k} data-status={EN[k]}>{lang === 'bn' ? `${BN[k]} (${EN[k]})` : EN[k]}</span>;
const Step = ({ n, name, children }) => <section className="card"><h2><span className="num">{n}</span>{name}</h2>{children}</section>;
const mb = (n) => (n / 1048576).toFixed(n < 1048576 ? 2 : 1) + ' MB';

export default function App() {
  const [lang, setLang] = useState('en');
  const [data, setData] = useState(null);
  const [files, setFiles] = useState([]);
  const [match, setMatch] = useState({}); // requirement id -> file id
  const [exp, setExp] = useState({});     // requirement id -> YYYY-MM-DD
  const [msgs, setMsgs] = useState([]);
  const [busy, setBusy] = useState(false);

  const t = (k, p = {}) => (D[lang][k] ?? D.en[k] ?? k).replace(/\{(\w+)\}/g, (_, x) => p[x] ?? '');
  const note = (kind, key, p) => setMsgs((m) => [...m, { id: nid(), kind, key, p }]);
  const reqs = data?.reqs || [];
  const tender = data?.tender;
  const deadline = tender?.submission_deadline;
  const title = (r) => (lang === 'bn' ? r.title_bn || r.title_en : r.title_en || r.title_bn);
  const label = (k) => (lang === 'bn' ? `${BN[k]} (${EN[k]})` : EN[k]);
  const fileOf = (r) => files.find((f) => f.id === match[r.id]);

  const statusOf = (r) => {
    if (!fileOf(r)) return r.mandatory ? 'missing' : 'notProvided';
    if (r.has_expiry) {
      const e = exp[r.id];
      if (!e) return 'expiryNeeded';
      if (e < deadline) return 'expired'; // equal to the deadline is still OK
    }
    return 'ok';
  };

  const dupMap = useMemo(() => { const g = {}; files.forEach((f) => (g[f.hash] ||= []).push(f)); return g; }, [files]);
  const dupsOf = (f) => (dupMap[f.hash] || []).filter((o) => o.id !== f.id);
  const usedBy = (fid) => reqs.find((r) => match[r.id] === fid);
  const dupClash = (f, rid) => dupsOf(f).find((o) => { const u = usedBy(o.id); return u && u.id !== rid; });

  async function onReq(e) {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    try {
      const d = parseRequirements(await f.text());
      setData(d); setMatch({}); setExp({});
    } catch (err) { note('err', 'eJson', { m: err.message }); }
  }

  async function addFiles(list) {
    const arr = [...list];
    if (!arr.length || busy) return;
    setBusy(true);
    const cur = [...files];
    let total = cur.reduce((s, f) => s + f.size, 0);
    for (const f of arr) {
      try {
        if (!/\.pdf$/i.test(f.name) && f.type !== 'application/pdf') { note('err', 'ePdfType', { n: f.name }); continue; }
        if (cur.length >= MAX_FILES) { note('err', 'eMany', { n: f.name }); continue; }
        if (total + f.size > MAX_BYTES) { note('err', 'eBig', { n: f.name }); continue; }
        const bytes = new Uint8Array(await f.arrayBuffer());
        if (!looksLikePdf(bytes)) { note('err', 'ePdfType', { n: f.name }); continue; }
        let pages;
        try { pages = await inspectPdf(bytes); }
        catch (err) { note('err', err.code === 'enc' ? 'eEnc' : 'eBad', { n: f.name }); continue; }
        const hash = await sha256(bytes);
        cur.push({ id: nid(), name: f.name, size: f.size, pages, hash, bytes });
        total += f.size;
      } catch (err) { note('err', 'eFile', { n: f.name, m: err.message }); }
    }
    setFiles(cur);
    setBusy(false);
  }

  function removeFile(f) {
    setFiles((fs) => fs.filter((x) => x.id !== f.id));
    const rids = Object.keys(match).filter((k) => match[k] === f.id);
    setMatch((m) => { const n = { ...m }; rids.forEach((k) => delete n[k]); return n; });
    setExp((x) => { const n = { ...x }; rids.forEach((k) => delete n[k]); return n; });
  }

  function pick(r, fid) {
    if (!fid) {
      setMatch((m) => { const n = { ...m }; delete n[r.id]; return n; });
      setExp((x) => ({ ...x, [r.id]: '' }));
      return;
    }
    if (match[r.id] === fid) return;
    const f = files.find((x) => x.id === fid);
    const clash = dupClash(f, r.id);
    if (clash) { note('err', 'eDup', { n: clash.name }); return; }
    const prev = usedBy(fid); // a file can belong to one document only: moving it frees the old one
    setMatch((m) => { const n = { ...m }; if (prev) delete n[prev.id]; n[r.id] = fid; return n; });
    setExp((x) => { const n = { ...x, [r.id]: '' }; if (prev) n[prev.id] = ''; return n; });
  }

  const blockers = reqs.filter((r) => BLOCK.includes(statusOf(r)));
  const counts = ORDER.map((k) => [k, reqs.filter((r) => statusOf(r) === k).length]);
  const hint = (r, s) => (s === 'missing' ? t('hMissing') : s === 'expiryNeeded' ? t('hExpNeed') : t('hExpired', { e: exp[r.id], d: deadline }));

  async function generate() {
    if (!data || blockers.length || busy) return;
    setBusy(true);
    try {
      const items = reqs.filter((r) => match[r.id]).map((r) => { const f = fileOf(r); return { req: r, name: f.name, bytes: f.bytes, pages: f.pages }; });
      const bytes = await buildPackage(tender, items);
      const name = `${tender.tender_id.replace(/[\\/:*?"<>|]/g, '_')}_Package.pdf`;
      const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
      const a = Object.assign(document.createElement('a'), { href: url, download: name });
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      note('ok', 'done', { n: name });
    } catch (err) { note('err', 'eGen', { m: err.message }); }
    setBusy(false);
  }

  const totalSize = files.reduce((s, f) => s + f.size, 0);

  return (
    <div className="app" lang={lang}>
      <header>
        <div><h1>{t('appTitle')}</h1><p>{t('sub')}</p></div>
        <div className="lang" role="group" aria-label="Language">
          <button className={lang === 'en' ? 'on' : ''} onClick={() => setLang('en')}>English</button>
          <button className={lang === 'bn' ? 'on' : ''} onClick={() => setLang('bn')}>বাংলা</button>
        </div>
      </header>

      <div className="msgs" aria-live="polite">
        {msgs.map((m) => (
          <div key={m.id} className={'msg ' + m.kind}>
            <span>{t(m.key, m.p)}</span>
            <button aria-label="Dismiss" onClick={() => setMsgs((x) => x.filter((y) => y.id !== m.id))}>×</button>
          </div>
        ))}
      </div>

      <Step n={1} name={t('s1')}>
        <label className="btn primary filebtn">{data ? t('reload') : t('open')}
          <input type="file" accept=".json,application/json" onChange={onReq} />
        </label>
        {!data && <p className="muted">{t('openHint')}</p>}
        {data && (<>
          <dl className="info">
            {[['tid', tender.tender_id], ['ttl', tender.title], ['ent', tender.procuring_entity], ['bid', tender.bidder], ['dl', tender.submission_deadline]].map(([k, v]) => (
              <div key={k}><dt>{t(k)}</dt><dd>{v || '—'}</dd></div>
            ))}
          </dl>
          <h3>{t('reqs')}</h3>
          <ol className="reqlist">
            {reqs.map((r) => (
              <li key={r.id}>
                <span className="ttl">{title(r)}</span>
                <span className={'tag ' + (r.mandatory ? 'm' : 'o')}>{r.mandatory ? t('mand') : t('opt')}</span>
                {r.has_expiry && <span className="tag e">{t('hasExp')}</span>}
              </li>
            ))}
          </ol>
        </>)}
      </Step>

      <Step n={2} name={t('s2')}>
        <label className="drop" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files); }}>
          <strong>{t('choose')}</strong>
          <span>{t('upHint')}</span>
          <input type="file" multiple accept=".pdf,application/pdf" disabled={busy} onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
        </label>
        <h3>{t('upFiles')} ({files.length}/{MAX_FILES}) <small>· {t('tot')}: {mb(totalSize)} / 50 MB</small></h3>
        {!files.length ? <p className="muted">{t('noFiles')}</p> : (
          <div className="scroll"><table>
            <thead><tr><th>{t('name')}</th><th>{t('pg')}</th><th>{t('size')}</th><th></th><th></th></tr></thead>
            <tbody>
              {files.map((f) => {
                const d = dupsOf(f), u = usedBy(f.id);
                return (
                  <tr key={f.id} className={d.length ? 'dup' : ''}>
                    <td className="fname">{f.name}</td><td>{f.pages}</td><td>{mb(f.size)}</td>
                    <td>
                      {d.length > 0 && <span className="badge s-expired" title={d.map((o) => o.name).join(', ')}>{t('dupOf', { n: d.map((o) => o.name).join(', ') })}</span>}{' '}
                      <span className="muted">{u ? t('usedFor', { n: title(u) }) : t('free')}</span>
                    </td>
                    <td><button className="btn small" onClick={() => removeFile(f)}>{t('remove')}</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table></div>
        )}
      </Step>

      <Step n={3} name={t('s3')}>
        {!data ? <p className="muted">{t('noReqBlock')}</p> : (<>
          <p className="muted">{t('s3hint')}</p>
          <div className="scroll"><table>
            <thead><tr><th>{t('doc')}</th><th>{t('file')}</th><th>{t('expiry')}</th></tr></thead>
            <tbody>
              {reqs.map((r) => (
                <tr key={r.id}>
                  <td><strong>{title(r)}</strong><br /><span className={'tag ' + (r.mandatory ? 'm' : 'o')}>{r.mandatory ? t('mand') : t('opt')}</span></td>
                  <td>
                    <div className="pickrow">
                      <select value={match[r.id] || ''} onChange={(e) => pick(r, e.target.value)} aria-label={title(r)}>
                        <option value="">{t('pick')}</option>
                        {files.map((f) => {
                          const u = usedBy(f.id), blocked = dupClash(f, r.id);
                          return <option key={f.id} value={f.id} disabled={!!blocked}>{f.name} ({f.pages} {t('pages')}){u && u.id !== r.id ? ` · ${title(u)}` : ''}{blocked ? ` · ${t('dupTag')}` : ''}</option>;
                        })}
                      </select>
                      {match[r.id] && <button className="btn small" onClick={() => pick(r, '')}>{t('undo')}</button>}
                    </div>
                  </td>
                  <td>
                    {!r.has_expiry ? <span className="muted">{t('noExp')}</span>
                      : !match[r.id] ? <span className="muted">{t('needFile')}</span>
                      : <input type="date" value={exp[r.id] || ''} onChange={(e) => setExp((x) => ({ ...x, [r.id]: e.target.value }))} aria-label={`${t('expiry')}: ${title(r)}`} />}
                  </td>
                </tr>
              ))}
            </tbody>
          </table></div>
        </>)}
      </Step>

      <Step n={4} name={t('s4')}>
        {!data ? <p className="muted">{t('noReqBlock')}</p> : (<>
          <div className="chips">{counts.map(([k, n]) => <span key={k} className={'chip s-' + k}>{label(k)}: <b>{n}</b></span>)}</div>
          <div className="scroll"><table>
            <thead><tr><th>{t('doc')}</th><th>{t('file')}</th><th>{t('expiry')}</th><th>{t('status')}</th></tr></thead>
            <tbody>
              {reqs.map((r) => {
                const s = statusOf(r), f = fileOf(r);
                return (
                  <tr key={r.id}>
                    <td><strong>{title(r)}</strong></td>
                    <td>{f ? <>{f.name} <span className="muted">({f.pages} {t('pages')})</span></> : '—'}</td>
                    <td>{r.has_expiry && f ? exp[r.id] || '—' : '—'}</td>
                    <td><Badge k={s} lang={lang} />{BLOCK.includes(s) && <div className="muted small">{hint(r, s)}</div>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table></div>
        </>)}
      </Step>

      <Step n={5} name={t('s5')}>
        {!data ? <p className="muted">{t('noReqBlock')}</p> : blockers.length ? (
          <div className="blocked">
            <p><strong>{t('blocked')}</strong></p>
            <ul>{blockers.map((r) => { const s = statusOf(r); return <li key={r.id}><b>{title(r)}</b> — {label(s)}. {hint(r, s)}</li>; })}</ul>
          </div>
        ) : <p className="readyok">✓ {t('ready')}</p>}
        <button className="btn primary big" disabled={!data || !!blockers.length || busy} onClick={generate}>{busy ? t('genning') : t('gen')}</button>
      </Step>
    </div>
  );
}
